import { createContext, useContext, useState, useCallback, useMemo } from 'react';

/**
 * Contexto do Carrinho de Compras.
 * 
 * COMO FUNCIONA O CONTEXT API:
 * 1. Criamos um contexto com createContext()
 * 2. O Provider envolve a aplicação e fornece o estado
 * 3. Qualquer componente filho pode acessar via useCart()
 * 4. Mudanças no estado re-renderizam apenas componentes que usam o contexto
 */
const CartContext = createContext();

/**
 * Provider do Carrinho - Gerencia o estado global do carrinho.
 * 
 * CICLO DE VIDA:
 * - Montagem: Inicializa o estado vazio
 * - Atualizações: Cada addToCart/removeFromCart dispara re-render
 * - Desmontagem: Estado é limpo automaticamente pelo React
 * 
 * @param {Object} props - Props do componente
 * @param {React.ReactNode} props.children - Componentes filhos
 */
export function CartProvider({ children }) {
    /**
     * useState: Armazena a lista de itens do carrinho.
     * 
     * ESTRUTURA DE CADA ITEM:
     * {
     *   productId: number,    // ID do produto
     *   productName: string,  // Nome para exibição
     *   price: number,        // Preço unitário (congelado no momento da adição)
     *   quantity: number      // Quantidade no carrinho
     * }
     */
    const [items, setItems] = useState([]);

    /**
     * Adiciona um produto ao carrinho.
     * 
     * LÓGICA:
     * - Se o produto já existe: incrementa a quantidade
     * - Se não existe: adiciona novo item com quantidade 1
     * 
     * useCallback: Memoriza a função para evitar re-criação desnecessária
     * em cada render. Dependências vazias [] pois não depende de props externas.
     */
    const addToCart = useCallback((product) => {
        setItems((prevItems) => {
            const existingItem = prevItems.find((item) => item.productId === product.id);

            if (existingItem) {
                // Produto já existe: incrementa quantidade
                return prevItems.map((item) =>
                    item.productId === product.id
                        ? { ...item, quantity: item.quantity + 1 }
                        : item
                );
            }

            // Produto novo: adiciona ao carrinho
            return [...prevItems, {
                productId: product.id,
                productName: product.name,
                price: product.price,
                quantity: 1,
            }];
        });
    }, []);

    /**
     * Remove um produto completamente do carrinho.
     */
    const removeFromCart = useCallback((productId) => {
        setItems((prevItems) => prevItems.filter((item) => item.productId !== productId));
    }, []);

    /**
     * Atualiza a quantidade de um item específico.
     * Se a quantidade for zero ou negativa, remove o item.
     */
    const updateQuantity = useCallback((productId, quantity) => {
        if (quantity <= 0) {
            removeFromCart(productId);
            return;
        }

        setItems((prevItems) =>
            prevItems.map((item) =>
                item.productId === productId ? { ...item, quantity } : item
            )
        );
    }, [removeFromCart]);

    /**
     * Limpa todos os itens do carrinho.
     * Chamado após checkout bem-sucedido.
     */
    const clearCart = useCallback(() => {
        setItems([]);
    }, []);

    /**
     * Calcula o total do carrinho.
     * 
     * useMemo: Memoriza o cálculo para evitar recalcular a cada render.
     * Só recalcula quando 'items' muda.
     */
    const total = useMemo(() => {
        return items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    }, [items]);

    /**
     * Conta a quantidade total de itens no carrinho.
     */
    const itemCount = useMemo(() => {
        return items.reduce((count, item) => count + item.quantity, 0);
    }, [items]);

    /**
     * Retorna os itens formatados para enviar à API de checkout.
     */
    const getCheckoutItems = useCallback(() => {
        return items.map((item) => ({
            productId: item.productId,
            quantity: item.quantity,
        }));
    }, [items]);

    // Funções de acesso para compatibilidade com código existente
    const getTotal = useCallback(() => total, [total]);
    const getItemCount = useCallback(() => itemCount, [itemCount]);

    /**
     * useMemo: Memoriza o objeto de valor do contexto.
     * Evita re-renderizações desnecessárias dos consumidores.
     */
    const value = useMemo(() => ({
        items,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        getTotal,
        getItemCount,
        getCheckoutItems,
        total,
        itemCount,
    }), [items, addToCart, removeFromCart, updateQuantity, clearCart,
        getTotal, getItemCount, getCheckoutItems, total, itemCount]);

    return (
        <CartContext.Provider value={value}>
            {children}
        </CartContext.Provider>
    );
}

/**
 * Hook customizado para acessar o contexto do carrinho.
 * 
 * USO:
 * const { items, addToCart, total } = useCart();
 * 
 * @throws {Error} Se usado fora do CartProvider
 */
export function useCart() {
    const context = useContext(CartContext);

    if (!context) {
        throw new Error('useCart deve ser usado dentro de um CartProvider');
    }

    return context;
}

import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Store } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useCartDrawer } from '../context/CartDrawerContext';

/**
 * Header do DevStore com botão para abrir o carrinho drawer.
 */
function Header() {
    const location = useLocation();
    const { itemCount } = useCart();
    const { open } = useCartDrawer();
    const isActive = (path) => location.pathname === path;

    return (
        <header className="sticky top-0 z-30 bg-white border-b border-gray-100 shadow-sm">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    {/* Logo */}
                    <Link to="/" className="flex items-center gap-2">
                        <div className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-lg flex items-center justify-center">
                            <Store className="w-5 h-5 text-white" />
                        </div>
                        <span className="text-xl font-bold text-gray-900">
                            Dev<span className="text-indigo-500">Store</span>
                        </span>
                    </Link>

                    {/* Navegação Central */}
                    <nav className="hidden md:flex items-center gap-6">
                        <Link
                            to="/"
                            className={`text-sm font-medium transition-colors ${isActive('/') ? 'text-indigo-600' : 'text-gray-600 hover:text-gray-900'
                                }`}
                        >
                            Produtos
                        </Link>
                        <Link
                            to="/admin"
                            className={`text-sm font-medium transition-colors ${isActive('/admin') ? 'text-indigo-600' : 'text-gray-600 hover:text-gray-900'
                                }`}
                        >
                            Admin
                        </Link>
                    </nav>

                    {/* Botão do Carrinho */}
                    <button
                        onClick={open}
                        className="relative w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors"
                    >
                        <ShoppingCart className="w-5 h-5 text-gray-700" />
                        {itemCount > 0 && (
                            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                                {itemCount > 9 ? '9+' : itemCount}
                            </span>
                        )}
                    </button>
                </div>
            </div>
        </header>
    );
}

export default Header;

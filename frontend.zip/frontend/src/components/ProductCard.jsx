import { useState, useCallback } from 'react';
import { ShoppingCart, Package, Check, ImageOff } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useCartNotification } from '../context/CartNotificationContext';
import { formatPrice } from '../utils/formatters';

/**
 * Card de produto com design moderno e imagem real.
 * 
 * Funcionalidades:
 * - Exibe imagem do produto vinda do banco (Base64)
 * - Fallback elegante para imagens ausentes ou quebradas
 * - Badge de quantidade quando produto está no carrinho
 * - Feedback visual no botão ao adicionar (NÃO abre drawer automaticamente)
 * - Notificação flutuante no canto inferior esquerdo
 */
function ProductCard({ product }) {
    const { addToCart, items } = useCart();
    const { notifyAddToCart } = useCartNotification();
    const [imageError, setImageError] = useState(false);
    const [isAdding, setIsAdding] = useState(false);

    // Verifica se o produto já está no carrinho
    const itemInCart = items.find(item => item.productId === product.id);
    const isInCart = !!itemInCart;

    const handleAddToCart = useCallback(() => {
        // Ativa estado de loading no botão
        setIsAdding(true);

        // Adiciona ao carrinho
        addToCart(product);

        // Mostra notificação flutuante (NÃO abre o drawer)
        notifyAddToCart(product.name, isInCart);

        // Feedback visual no botão por 1 segundo
        setTimeout(() => {
            setIsAdding(false);
        }, 1000);
    }, [addToCart, product, notifyAddToCart, isInCart]);

    /**
     * Handler para erro de carregamento de imagem.
     */
    const handleImageError = useCallback(() => {
        setImageError(true);
    }, []);

    const isOutOfStock = product.stock === 0;
    const isLowStock = product.stock > 0 && product.stock < 5;
    const showPlaceholder = !product.image || imageError;

    // Determina texto e estilo do botão
    const getButtonContent = () => {
        if (isAdding) {
            return (
                <>
                    <Check className="w-4 h-4" />
                    Adicionado!
                </>
            );
        }
        if (isOutOfStock) {
            return (
                <>
                    <ShoppingCart className="w-4 h-4" />
                    Indisponível
                </>
            );
        }
        if (isInCart) {
            return (
                <>
                    <ShoppingCart className="w-4 h-4" />
                    Adicionar mais
                </>
            );
        }
        return (
            <>
                <ShoppingCart className="w-4 h-4" />
                Comprar
            </>
        );
    };

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-300 group">
            {/* Container da Imagem */}
            <div className="relative h-52 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center overflow-hidden">
                {showPlaceholder ? (
                    <div className="flex flex-col items-center justify-center text-gray-300 group-hover:scale-105 transition-transform duration-300">
                        {imageError ? (
                            <>
                                <ImageOff className="w-16 h-16 mb-2" />
                                <span className="text-xs font-medium">Imagem indisponível</span>
                            </>
                        ) : (
                            <Package className="w-20 h-20" />
                        )}
                    </div>
                ) : (
                    <img
                        src={product.image}
                        alt={product.name}
                        onError={handleImageError}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="lazy"
                    />
                )}

                {/* Badge de estoque */}
                {!isOutOfStock && (
                    <span className={`absolute top-3 left-3 px-2.5 py-1 text-xs font-semibold rounded-full shadow-sm ${isLowStock
                        ? 'bg-orange-100 text-orange-700'
                        : 'bg-green-100 text-green-700'
                        }`}>
                        {isLowStock ? 'POUCAS UNIDADES' : 'EM ESTOQUE'}
                    </span>
                )}
                {isOutOfStock && (
                    <span className="absolute top-3 left-3 px-2.5 py-1 text-xs font-semibold rounded-full bg-gray-200 text-gray-600 shadow-sm">
                        ESGOTADO
                    </span>
                )}

                {/* Badge se já está no carrinho */}
                {isInCart && !isOutOfStock && (
                    <span className="absolute top-3 right-3 px-2.5 py-1 text-xs font-semibold rounded-full bg-indigo-500 text-white shadow-sm flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        {itemInCart.quantity}x
                    </span>
                )}
            </div>

            {/* Conteúdo */}
            <div className="p-5">
                {/* Título */}
                <h3 className="font-bold text-gray-800 mb-2 line-clamp-2 min-h-[2.5rem]">
                    {product.name}
                </h3>

                {/* Preço */}
                <p className="text-2xl font-bold text-gray-900 mb-4">
                    {formatPrice(product.price)}
                </p>

                {/* Botão Comprar com feedback visual */}
                <button
                    onClick={handleAddToCart}
                    disabled={isOutOfStock || isAdding}
                    className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-semibold transition-all duration-200 ${isAdding
                        ? 'bg-green-500 text-white'
                        : isOutOfStock
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : isInCart
                                ? 'bg-indigo-100 text-indigo-700 hover:bg-indigo-200'
                                : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-600/25'
                        }`}
                >
                    {getButtonContent()}
                </button>
            </div>
        </div>
    );
}

export default ProductCard;

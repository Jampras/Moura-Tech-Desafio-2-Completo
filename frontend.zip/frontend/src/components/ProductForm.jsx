import { useState } from 'react';
import { useToast } from './Toast';
import ProductService from '../services/ProductService';
import './ProductForm.css';

/**
 * Formulário para criação/edição de produtos.
 * Valida preço negativo antes de enviar.
 */
function ProductForm({ product = null, onSuccess, onCancel }) {
    const toast = useToast();
    const [formData, setFormData] = useState({
        name: product?.name || '',
        price: product?.price?.toString() || '',
        stock: product?.stock?.toString() || '',
    });
    const [errors, setErrors] = useState({});
    const [submitting, setSubmitting] = useState(false);

    const isEditing = !!product;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));

        // Limpa o erro do campo quando o usuário digita
        if (errors[name]) {
            setErrors((prev) => ({ ...prev, [name]: null }));
        }
    };

    /**
     * Validação do formulário antes de enviar.
     * REGRA: Preço não pode ser negativo ou zero.
     */
    const validate = () => {
        const newErrors = {};

        // Valida nome
        if (!formData.name.trim()) {
            newErrors.name = 'O nome do produto é obrigatório';
        }

        // Valida preço
        const price = parseFloat(formData.price);
        if (isNaN(price)) {
            newErrors.price = 'Informe um preço válido';
        } else if (price <= 0) {
            newErrors.price = 'O preço deve ser maior que zero';
        }

        // Valida estoque
        const stock = parseInt(formData.stock, 10);
        if (isNaN(stock)) {
            newErrors.stock = 'Informe um estoque válido';
        } else if (stock < 0) {
            newErrors.stock = 'O estoque não pode ser negativo';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Valida antes de enviar
        if (!validate()) {
            toast.error('Corrija os erros do formulário');
            return;
        }

        setSubmitting(true);

        try {
            const productData = {
                name: formData.name.trim(),
                price: parseFloat(formData.price),
                stock: parseInt(formData.stock, 10),
            };

            if (isEditing) {
                await ProductService.updateProduct(product.id, productData);
                toast.success('Produto atualizado com sucesso!');
            } else {
                await ProductService.createProduct(productData);
                toast.success('Produto criado com sucesso!');
            }

            // Limpa o formulário
            setFormData({ name: '', price: '', stock: '' });

            // Callback de sucesso
            if (onSuccess) onSuccess();

        } catch (err) {
            // Exibe erro do backend
            toast.error(err.message || 'Erro ao salvar produto');

            // Se houver erros de validação, mostra cada um
            if (err.validationErrors && err.validationErrors.length > 0) {
                err.validationErrors.forEach((msg) => toast.warning(msg));
            }
        } finally {
            setSubmitting(false);
        }
    };

    const handleReset = () => {
        setFormData({ name: '', price: '', stock: '' });
        setErrors({});
        if (onCancel) onCancel();
    };

    return (
        <form className="product-form" onSubmit={handleSubmit}>
            <div className="form-group">
                <label htmlFor="name">Nome do Produto *</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Ex: Camiseta Polo"
                    className={errors.name ? 'input-error' : ''}
                />
                {errors.name && <span className="error-message">{errors.name}</span>}
            </div>

            <div className="form-row">
                <div className="form-group">
                    <label htmlFor="price">Preço (R$) *</label>
                    <input
                        type="number"
                        id="price"
                        name="price"
                        value={formData.price}
                        onChange={handleChange}
                        placeholder="99.90"
                        step="0.01"
                        className={errors.price ? 'input-error' : ''}
                    />
                    {errors.price && <span className="error-message">{errors.price}</span>}
                </div>

                <div className="form-group">
                    <label htmlFor="stock">Estoque *</label>
                    <input
                        type="number"
                        id="stock"
                        name="stock"
                        value={formData.stock}
                        onChange={handleChange}
                        placeholder="50"
                        className={errors.stock ? 'input-error' : ''}
                    />
                    {errors.stock && <span className="error-message">{errors.stock}</span>}
                </div>
            </div>

            <div className="form-actions">
                <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={submitting}
                >
                    {submitting ? 'Salvando...' : isEditing ? 'Atualizar' : 'Cadastrar'}
                </button>

                {(isEditing || onCancel) && (
                    <button
                        type="button"
                        className="btn btn-secondary"
                        onClick={handleReset}
                    >
                        Cancelar
                    </button>
                )}
            </div>
        </form>
    );
}

export default ProductForm;

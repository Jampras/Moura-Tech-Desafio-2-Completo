import { useState, useMemo } from 'react';
import { Loader2, Package, AlertCircle, Search, SearchX, Filter } from 'lucide-react';
import ProductCard from './ProductCard';

/**
 * Sidebar de filtros funcional com estados controlados.
 */
function Sidebar({ filters, onFilterChange }) {
    return (
        <aside className="w-64 flex-shrink-0 hidden lg:block">
            <div className="sticky top-24 space-y-6">
                {/* Barra de Busca */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <Search className="w-4 h-4" />
                        Buscar
                    </h3>
                    <div className="relative">
                        <input
                            type="text"
                            value={filters.searchTerm}
                            onChange={(e) => onFilterChange('searchTerm', e.target.value)}
                            placeholder="Nome do produto..."
                            className="w-full px-4 py-2.5 pl-10 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                        />
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    </div>
                </div>

                {/* Categorias */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                    <h3 className="font-bold text-gray-900 mb-4">Categorias</h3>
                    <ul className="space-y-2">
                        {['Todos', 'Periféricos', 'Monitores', 'Áudio', 'Móveis'].map((cat) => (
                            <li key={cat}>
                                <label className="flex items-center gap-3 cursor-pointer group">
                                    <input
                                        type="radio"
                                        name="categoria"
                                        checked={filters.categoria === cat}
                                        onChange={() => onFilterChange('categoria', cat)}
                                        className="w-4 h-4 text-indigo-600 focus:ring-indigo-500 border-gray-300"
                                    />
                                    <span className="text-sm text-gray-600 group-hover:text-gray-900 transition-colors">
                                        {cat}
                                    </span>
                                </label>
                            </li>
                        ))}
                    </ul>
                </div>

                {/* Disponibilidade */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <Filter className="w-4 h-4" />
                        Disponibilidade
                    </h3>
                    <ul className="space-y-3">
                        <li>
                            <label className="flex items-center gap-3 cursor-pointer group">
                                <input
                                    type="checkbox"
                                    checked={filters.emEstoque}
                                    onChange={(e) => onFilterChange('emEstoque', e.target.checked)}
                                    className="w-4 h-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                                />
                                <span className="text-sm text-gray-600 group-hover:text-gray-900 transition-colors">
                                    Em estoque
                                </span>
                            </label>
                        </li>
                        <li>
                            <label className="flex items-center gap-3 cursor-pointer group">
                                <input
                                    type="checkbox"
                                    checked={filters.ultimasUnidades}
                                    onChange={(e) => onFilterChange('ultimasUnidades', e.target.checked)}
                                    className="w-4 h-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                                />
                                <span className="text-sm text-gray-600 group-hover:text-gray-900 transition-colors">
                                    Últimas unidades (≤5)
                                </span>
                            </label>
                        </li>
                    </ul>
                </div>

                {/* Faixa de Preço */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                    <h3 className="font-bold text-gray-900 mb-4">Faixa de Preço</h3>
                    <div className="space-y-3">
                        <input
                            type="range"
                            min="0"
                            max="5000"
                            step="100"
                            value={filters.precoMax}
                            onChange={(e) => onFilterChange('precoMax', parseInt(e.target.value))}
                            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                        />
                        <div className="flex justify-between text-sm text-gray-500">
                            <span>R$ 0</span>
                            <span className="font-medium text-indigo-600">
                                {filters.precoMax === 5000 ? 'Sem limite' : `Até R$ ${filters.precoMax.toLocaleString('pt-BR')}`}
                            </span>
                        </div>
                    </div>
                </div>

                {/* Botão Limpar Filtros */}
                <button
                    onClick={() => onFilterChange('reset', null)}
                    className="w-full py-2.5 text-sm font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                >
                    Limpar filtros
                </button>
            </div>
        </aside>
    );
}

/**
 * Componente de "Nenhum produto encontrado"
 */
function EmptyFilterResults({ searchTerm, onClearFilters }) {
    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center mx-auto mb-6">
                <SearchX className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Nenhum produto encontrado
            </h3>
            <p className="text-gray-500 mb-6 max-w-md mx-auto">
                {searchTerm
                    ? `Não encontramos produtos com "${searchTerm}". Tente buscar por outro termo.`
                    : 'Nenhum produto corresponde aos filtros selecionados. Tente ajustar os critérios.'}
            </p>
            <button
                onClick={onClearFilters}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg transition-colors"
            >
                <Filter className="w-4 h-4" />
                Limpar filtros
            </button>
        </div>
    );
}

/**
 * Lista de produtos em grid com filtros funcionais.
 */
function ProductList({ products, loading, error, onRetry }) {
    // Estado dos filtros
    const [filters, setFilters] = useState({
        searchTerm: '',
        categoria: 'Todos',
        emEstoque: false,
        ultimasUnidades: false,
        precoMax: 5000,
    });

    // Handler para atualizar filtros
    const handleFilterChange = (field, value) => {
        if (field === 'reset') {
            setFilters({
                searchTerm: '',
                categoria: 'Todos',
                emEstoque: false,
                ultimasUnidades: false,
                precoMax: 5000,
            });
        } else {
            setFilters(prev => ({ ...prev, [field]: value }));
        }
    };

    // Lógica combinada de filtragem (memoizada para performance)
    const filteredProducts = useMemo(() => {
        return products.filter(product => {
            // Filtro por nome (case insensitive)
            const matchesSearch = product.name
                .toLowerCase()
                .includes(filters.searchTerm.toLowerCase());

            // Filtro "Em estoque" (stock > 0)
            const matchesEmEstoque = filters.emEstoque
                ? product.stock > 0
                : true;

            // Filtro "Últimas unidades" (stock > 0 && stock <= 5)
            const matchesUltimasUnidades = filters.ultimasUnidades
                ? product.stock > 0 && product.stock <= 5
                : true;

            // Filtro de preço máximo
            const matchesPreco = filters.precoMax === 5000
                ? true
                : product.price <= filters.precoMax;

            // Combina todos os filtros
            return matchesSearch && matchesEmEstoque && matchesUltimasUnidades && matchesPreco;
        });
    }, [products, filters]);

    // Verifica se há filtros ativos
    const hasActiveFilters = filters.searchTerm ||
        filters.categoria !== 'Todos' ||
        filters.emEstoque ||
        filters.ultimasUnidades ||
        filters.precoMax < 5000;

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                <Loader2 className="w-10 h-10 animate-spin text-indigo-500 mb-4" />
                <p className="font-medium">Carregando produtos...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
                <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Erro ao carregar</h3>
                <p className="text-gray-500 mb-4">{error}</p>
                {onRetry && (
                    <button onClick={onRetry} className="btn-primary">
                        Tentar novamente
                    </button>
                )}
            </div>
        );
    }

    if (products.length === 0) {
        return (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
                <Package className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhum produto</h3>
                <p className="text-gray-500">
                    Acesse <span className="font-semibold text-indigo-600">Admin</span> para adicionar produtos.
                </p>
            </div>
        );
    }

    return (
        <div className="flex gap-8">
            {/* Sidebar de Filtros */}
            <Sidebar filters={filters} onFilterChange={handleFilterChange} />

            {/* Grid de Produtos */}
            <div className="flex-1">
                {/* Contador de resultados */}
                {hasActiveFilters && (
                    <div className="mb-4 flex items-center justify-between">
                        <p className="text-sm text-gray-500">
                            <span className="font-semibold text-gray-900">{filteredProducts.length}</span>
                            {filteredProducts.length === 1 ? ' produto encontrado' : ' produtos encontrados'}
                        </p>
                        {filters.searchTerm && (
                            <span className="text-sm text-gray-500">
                                Buscando: <span className="font-medium text-indigo-600">"{filters.searchTerm}"</span>
                            </span>
                        )}
                    </div>
                )}

                {/* Resultado vazio após filtragem */}
                {filteredProducts.length === 0 ? (
                    <EmptyFilterResults
                        searchTerm={filters.searchTerm}
                        onClearFilters={() => handleFilterChange('reset', null)}
                    />
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                        {filteredProducts.map((product) => (
                            <ProductCard key={product.id} product={product} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

export default ProductList;

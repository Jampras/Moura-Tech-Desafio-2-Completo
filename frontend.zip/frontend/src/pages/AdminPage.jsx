import { useState, useEffect, useCallback } from 'react';
import { Settings, Plus, Pencil, Trash2, Loader2, Package } from 'lucide-react';
import ProductService from '../services/ProductService';
import ProductModal from '../components/ProductModal';
import { useToast } from '../components/Toast';
import { formatPrice } from '../utils/formatters';

/**
 * Página de administração de produtos com modal.
 */
function AdminPage() {
    const toast = useToast();
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);

    // Controle do Modal
    const [modalOpen, setModalOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState(null);

    /**
     * EFEITO: Carrega lista de produtos ao montar o componente.
     * GATILHO: [] (array vazio = apenas na montagem)
     * RISCO DE LOOP: Nenhum (dependências vazias)
     */
    useEffect(() => {
        loadProducts();
    }, []);

    const loadProducts = async () => {
        try {
            setLoading(true);
            const data = await ProductService.getProducts();
            setProducts(data);
        } catch (err) {
            toast.error(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handleNewProduct = () => {
        setEditingProduct(null);
        setModalOpen(true);
    };

    const handleEdit = (product) => {
        setEditingProduct(product);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setModalOpen(false);
        setEditingProduct(null);
    };

    const handleSuccess = () => {
        loadProducts();
    };

    const handleDelete = async (id, name) => {
        if (!confirm(`Excluir "${name}"?`)) return;
        try {
            await ProductService.deleteProduct(id);
            toast.success('Produto excluído!');
            loadProducts();
        } catch (err) {
            toast.error(err.message);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                            <Settings className="w-7 h-7 text-primary-500" />
                            Administração
                        </h1>
                        <p className="text-gray-500 text-sm mt-1">
                            Gerencie os produtos da loja
                        </p>
                    </div>

                    <button
                        onClick={handleNewProduct}
                        className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl transition-colors shadow-lg shadow-indigo-600/25"
                    >
                        <Plus className="w-5 h-5" />
                        Novo Produto
                    </button>
                </div>

                {/* Tabela de Produtos */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                    {loading ? (
                        <div className="flex items-center justify-center py-20">
                            <Loader2 className="w-8 h-8 animate-spin text-primary-500" />
                        </div>
                    ) : products.length === 0 ? (
                        <div className="text-center py-20">
                            <Package className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                            <p className="text-gray-500">Nenhum produto cadastrado.</p>
                            <button
                                onClick={handleNewProduct}
                                className="mt-4 text-indigo-600 font-medium hover:text-indigo-700"
                            >
                                Cadastrar primeiro produto
                            </button>
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="text-left py-4 px-6 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                            ID
                                        </th>
                                        <th className="text-left py-4 px-6 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                            Produto
                                        </th>
                                        <th className="text-left py-4 px-6 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                            Preço
                                        </th>
                                        <th className="text-left py-4 px-6 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                            Estoque
                                        </th>
                                        <th className="text-right py-4 px-6 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                            Ações
                                        </th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100">
                                    {products.map((product) => (
                                        <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                                            <td className="py-4 px-6 text-sm text-gray-400">
                                                #{product.id}
                                            </td>
                                            <td className="py-4 px-6">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
                                                        {product.image ? (
                                                            <img
                                                                src={product.image}
                                                                alt={product.name}
                                                                className="w-full h-full object-cover"
                                                            />
                                                        ) : (
                                                            <Package className="w-5 h-5 text-gray-400" />
                                                        )}
                                                    </div>
                                                    <span className="font-medium text-gray-900">
                                                        {product.name}
                                                    </span>
                                                </div>
                                            </td>
                                            <td className="py-4 px-6 text-indigo-600 font-semibold">
                                                {formatPrice(product.price)}
                                            </td>
                                            <td className="py-4 px-6">
                                                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${product.stock === 0
                                                    ? 'bg-red-100 text-red-700'
                                                    : product.stock <= 5
                                                        ? 'bg-orange-100 text-orange-700'
                                                        : 'bg-green-100 text-green-700'
                                                    }`}>
                                                    {product.stock} un.
                                                </span>
                                            </td>
                                            <td className="py-4 px-6 text-right">
                                                <div className="flex items-center justify-end gap-1">
                                                    <button
                                                        onClick={() => handleEdit(product)}
                                                        className="p-2 hover:bg-indigo-50 rounded-lg text-gray-500 hover:text-indigo-600 transition-colors"
                                                        title="Editar"
                                                    >
                                                        <Pencil className="w-4 h-4" />
                                                    </button>
                                                    <button
                                                        onClick={() => handleDelete(product.id, product.name)}
                                                        className="p-2 hover:bg-red-50 rounded-lg text-gray-500 hover:text-red-600 transition-colors"
                                                        title="Excluir"
                                                    >
                                                        <Trash2 className="w-4 h-4" />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>

            {/* Modal de Produto */}
            <ProductModal
                isOpen={modalOpen}
                onClose={handleCloseModal}
                product={editingProduct}
                onSuccess={handleSuccess}
            />
        </div>
    );
}

export default AdminPage;

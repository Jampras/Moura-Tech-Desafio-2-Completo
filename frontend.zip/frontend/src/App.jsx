import { Routes, Route } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import { CartDrawerProvider } from './context/CartDrawerContext';
import { CartNotificationProvider } from './context/CartNotificationContext';
import { ToastProvider } from './components/Toast';
import Header from './components/Header';
import Cart from './components/Cart';
import ToastNotification from './components/ToastNotification';
import HomePage from './pages/HomePage';
import AdminPage from './pages/AdminPage';

/**
 * Componente raiz da aplicação.
 * 
 * Hierarquia de Providers:
 * - ToastProvider: Toasts gerais da aplicação
 * - CartProvider: Estado global do carrinho
 * - CartDrawerProvider: Controle de abertura/fechamento do drawer
 * - CartNotificationProvider: Notificações flutuantes do carrinho
 */
function App() {
    return (
        <ToastProvider>
            <CartProvider>
                <CartDrawerProvider>
                    <CartNotificationProvider>
                        <div className="min-h-screen bg-gray-50">
                            <Header />
                            <main className="animate-fade-in">
                                <Routes>
                                    <Route path="/" element={<HomePage />} />
                                    <Route path="/admin" element={<AdminPage />} />
                                </Routes>
                            </main>

                            {/* Cart Drawer (direita) */}
                            <Cart />

                            {/* Toast de Notificação do Carrinho (canto inferior esquerdo) */}
                            <ToastNotification />
                        </div>
                    </CartNotificationProvider>
                </CartDrawerProvider>
            </CartProvider>
        </ToastProvider>
    );
}

export default App;
